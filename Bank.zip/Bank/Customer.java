public class Customer {
    private String customerName;
    private int customerId;
    private Account account;

    public Customer(String customerName, int id, Account account) {
        this.customerId = id;
        this.customerName = customerName;
        this.account = account;
    }
}
