import java.util.ArrayList;
import java.util.Scanner;

public class ArrayDemo {
    // Collection of Elements
    public static void main(String[] args) {
        int a = 10;
        int[] arr2 = new int[5];
        // arr[2] = 90;
        int arr[] = { 1, 2, 3, 4, 5 };
        int arr1[] = new int[] { 1, 2, 3, 4 };
        // Scanner sc = new Scanner(System.in);

        // for (int i = 0; i < arr2.length; i++) {
        // arr2[i] = sc.nextInt();
        // }

        // for (int i = 0; i < arr2.length; i++) {
        // System.out.print(arr2[i] + " ");
        // }

        // int sum = 0;

        // for (int i = 0; i < arr2.length; i++) {
        // sum += arr2[i];
        // }
        // System.out.println();
        // System.out.println(sum);

        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        // list.add(3 ,2);
        list.add(3);
        list.add(4);
        list.add(5);
        System.out.println(list.get(3));
        list.remove(3);
        System.out.println(list);
        System.out.println(list.size());
        list.clear();
        System.out.println(list);
        
    }
}
