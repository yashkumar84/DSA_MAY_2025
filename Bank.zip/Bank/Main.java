import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Bank sbi = new Bank("State Bank Of India");
        int choice;
        do {
            System.out.println("Press 1 for Open New Account");
            System.out.println("Press 2 for Printing All Customers");
            System.out.println("Press 3 for Deposit Money");
            System.out.println("Press 4 for Withdraw Money");
            System.out.println("Press 5 For Printing the Transaction History");
            System.out.println("Press 6 For Transfer Money..");
            System.out.println("Press 7 for Exit");

            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter Name Of Customer");
                    sc.nextLine();
                    String name = sc.nextLine();
                    System.out.println("Enter Password: ");
                    int password = sc.nextInt();
                    System.out.println("Enter the Initial Amount");
                    double amount = sc.nextDouble();
                    System.out.println("Enter the Account Number");
                    int accountNumber = sc.nextInt();
                    Account newAccount = new Account(accountNumber, password, amount);
                    Customer newCustomer = new Customer(name, accountNumber, newAccount);
                    sbi.addCustomer(newCustomer);
                    break;
                case 2:
                    sbi.printCustomers();
                    break;
                case 3:
                    System.out.println("Enter the Account Number.....");
                    int accNo = sc.nextInt();
                    Account acc = sbi.getAccountByAccountNumber(accNo);
                    if (acc == null) {
                        System.out.println("Account Doesn't Exist");
                        return;
                    }
                    System.out.println("Enter the Amount to Deposit");
                    double amountToDeposit = sc.nextDouble();
                    acc.deposit(amountToDeposit);
                    break;
                case 4:
                    System.out.println("Enter the Account Number.....");
                    int accNoTowithdraw = sc.nextInt();
                    Account withdrawAcc = sbi.getAccountByAccountNumber(accNoTowithdraw);
                    if (withdrawAcc == null) {
                        System.out.println("Account Doesn't Exist");
                        return;
                    }
                    System.out.println("Enter the password... ");
                    int pass = sc.nextInt();
                    System.out.println("Enter the Amount to Withdraw");
                    double amountToWithdraw = sc.nextDouble();
                    withdrawAcc.withdraw(amountToWithdraw, pass);
                    break;
                case 5:
                    System.out.println("Enter the Account Number.....");
                    int accNoForTrans = sc.nextInt();
                    Account accForTrans = sbi.getAccountByAccountNumber(accNoForTrans);
                    if (accForTrans == null) {
                        System.out.println("Account Doesn't Exist");
                        return;
                    }
                    System.out.println("Enter the password... ");
                    int passForTrans = sc.nextInt();
                    if (passForTrans != accForTrans.getPassword()) {
                        System.out.println("Invalid Password");
                        return;
                    }
                    accForTrans.printTransactionHistory();
                    break;
                case 6:
                    System.out.println("Enter the Account Number.....");
                    int fromAccNo = sc.nextInt();
                    Account fromAcc = sbi.getAccountByAccountNumber(fromAccNo);
                    if (fromAcc == null) {
                        System.out.println("From Account Doesn't Exist");
                        return;
                    }
                    System.out.println("Enter the password... ");
                    int fromAccPass = sc.nextInt();
                    if (fromAcc.getPassword() != fromAccPass) {
                        System.out.println("Invalid Password");
                        return;
                    }
                    System.out.println("Enter Reciever Account Number To Transfer");
                    int toAccNo = sc.nextInt();
                    Account toAcc = sbi.getAccountByAccountNumber(toAccNo);
                    if (toAcc == null) {
                        System.out.println("Reciever Account Doesn't Exist");
                        return;
                    }
                    System.out.println("Enter the Amount to Transfer");
                    double amountToTransfer = sc.nextDouble();
                    fromAcc.transferMoney(toAcc, amountToTransfer);
                    break;
                default:
                    System.out.println("Enter the Correct Choice This is Wrong Choice see Again and press correct 1");
                    break;
            }
        } while (choice != 7);
    }

}
