import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Bank sbi = new Bank("State Bank Of India");
        int choice;
        do {
            System.out.println("Press 1 for Open New Account");
            System.out.println("Press 2 for Printing All Customers");
            System.out.println("Press 5 for Exit");

            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter Name Of Customer");
                    sc.nextLine();
                    String name = sc.nextLine();
                    System.out.println("Enter Password: ");
                    int password = sc.nextInt();
                    System.out.println("Enter the Initial Amount");
                    double amount = sc.nextDouble();
                    System.out.println("Enter the Account Number");
                    int accountNumber = sc.nextInt();
                    Account newAccount = new Account(accountNumber, password, amount);
                    Customer newCustomer = new Customer(name, accountNumber, newAccount);
                    sbi.addCustomer(newCustomer);
                    break;
                case 2:
                    sbi.printCustomers();
                    break;
                default:
                    break;
            }
        } while (choice != 5);
    }

}
