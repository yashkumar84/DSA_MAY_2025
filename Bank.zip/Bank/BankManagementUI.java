import javax.swing.*;
import java.awt.*;
// import java.awt.event.*;

public class BankManagementUI {
    private Bank sbi;
    private JFrame mainFrame;

    public BankManagementUI() {
        prepareGUI();
    }

    private void prepareGUI() {
        sbi = new Bank("State Bank Of India");
        mainFrame = new JFrame("Bank Management System");
        mainFrame.setSize(600, 600);
        mainFrame.setLayout(new GridLayout(5, 1, 10, 10));
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton openAccountBtn = new JButton("Open Account");
        JButton withdrawBtn = new JButton("Withdraw");
        JButton depositBtn = new JButton("Deposit");
        JButton checkBalanceBtn = new JButton("Check Balance");
        JButton exitBtn = new JButton("Exit");

        // Button actions
        openAccountBtn.addActionListener(e -> openAccountForm());
        withdrawBtn.addActionListener(e -> withdrawForm());
        depositBtn.addActionListener(e -> depositForm());
        checkBalanceBtn.addActionListener(e -> checkBalanceForm());
        exitBtn.addActionListener(e -> System.exit(0));

        mainFrame.add(openAccountBtn);
        mainFrame.add(withdrawBtn);
        mainFrame.add(depositBtn);
        mainFrame.add(checkBalanceBtn);
        mainFrame.add(exitBtn);

        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }

    private void openAccountForm() {
        JFrame frame = new JFrame("Open Account");
        frame.setSize(300, 300);
        frame.setLayout(new GridLayout(5, 2, 5, 5));

        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField();

        JLabel passwordLabel = new JLabel("Password:");
        JTextField passwordField = new JTextField();

        JLabel depositLabel = new JLabel("Initial Deposit:");
        JTextField depositField = new JTextField();

        JLabel accountNoLabel = new JLabel("Account Number :");
        JTextField accountNoField = new JTextField();

        JButton submitBtn = new JButton("Submit");

        submitBtn.addActionListener(e -> {
            String name = nameField.getText();
            int password = Integer.parseInt(passwordField.getText());
            double deposit = Double.parseDouble(depositField.getText());
            int accNo = Integer.parseInt(accountNoField.getText());
            Account newAccount = new Account(accNo, password, deposit);
            Customer newCustomer = new Customer(name, accNo, newAccount);
            sbi.addCustomer(newCustomer);
            JOptionPane.showMessageDialog(frame,
                    "Account Created!\nName: " + name + "\nPassword: " + password + "\nDeposit: " + deposit);
            frame.dispose();
        });

        frame.add(nameLabel);
        frame.add(nameField);
        frame.add(passwordLabel);
        frame.add(passwordField);
        frame.add(depositLabel);
        frame.add(depositField);
        frame.add(accountNoLabel);
        frame.add(accountNoField);
        frame.add(new JLabel());
        frame.add(submitBtn);

        frame.setLocationRelativeTo(mainFrame);
        frame.setVisible(true);
    }

    private void withdrawForm() {
        JFrame frame = new JFrame("Withdraw Money");
        frame.setSize(300, 200);
        frame.setLayout(new GridLayout(3, 2, 5, 5));

        JLabel accLabel = new JLabel("Account Number:");
        JTextField accField = new JTextField();

        JLabel amountLabel = new JLabel("Amount:");
        JTextField amountField = new JTextField();

        JButton submitBtn = new JButton("Withdraw");

        submitBtn.addActionListener(e -> {
            String accNo = accField.getText();
            double amount = Double.parseDouble(amountField.getText());

            JOptionPane.showMessageDialog(frame,
                    "Withdrawn " + amount + " from Account " + accNo);
            frame.dispose();
        });

        frame.add(accLabel);
        frame.add(accField);
        frame.add(amountLabel);
        frame.add(amountField);
        frame.add(new JLabel());
        frame.add(submitBtn);

        frame.setLocationRelativeTo(mainFrame);
        frame.setVisible(true);
    }

    private void depositForm() {
        JFrame frame = new JFrame("Deposit Money");
        frame.setSize(300, 200);
        frame.setLayout(new GridLayout(3, 2, 5, 5));

        JLabel accLabel = new JLabel("Account Number:");
        JTextField accField = new JTextField();

        JLabel amountLabel = new JLabel("Amount:");
        JTextField amountField = new JTextField();

        JButton submitBtn = new JButton("Deposit");

        submitBtn.addActionListener(e -> {
            String accNo = accField.getText();
            double amount = Double.parseDouble(amountField.getText());

            JOptionPane.showMessageDialog(frame,
                    "Deposited " + amount + " to Account " + accNo);
            frame.dispose();
        });

        frame.add(accLabel);
        frame.add(accField);
        frame.add(amountLabel);
        frame.add(amountField);
        frame.add(new JLabel());
        frame.add(submitBtn);

        frame.setLocationRelativeTo(mainFrame);
        frame.setVisible(true);
    }

    private void checkBalanceForm() {
        JFrame frame = new JFrame("Check Balance");
        frame.setSize(300, 150);
        frame.setLayout(new GridLayout(2, 2, 5, 5));

        JLabel accLabel = new JLabel("Account Number:");
        JTextField accField = new JTextField();

        JButton submitBtn = new JButton("Check");

        submitBtn.addActionListener(e -> {
            String accNo = accField.getText();
            // For demo purpose, fixed balance
            double balance = 5000.00;
            JOptionPane.showMessageDialog(frame,
                    "Account " + accNo + " has balance: " + balance);
            frame.dispose();
        });

        frame.add(accLabel);
        frame.add(accField);
        frame.add(new JLabel());
        frame.add(submitBtn);

        frame.setLocationRelativeTo(mainFrame);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        // SwingUtilities.invokeLater(BankManagementUI::new);
        BankManagementUI ui = new BankManagementUI();
    }
}
