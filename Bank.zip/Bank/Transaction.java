import java.util.Date;

public class Transaction {
    private int transactionId;
    private double transactionAmount;
    private String transactionType;
    private Date date;
    private double balanceLeft;

    public Transaction(int id, double amount, String type, Date date, double balanceLeft) {
        this.transactionId = id;
        this.transactionType = type;
        this.transactionAmount = amount;
        this.date = date;
        this.balanceLeft = balanceLeft;
    }

}
