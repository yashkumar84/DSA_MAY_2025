import java.util.Date;

public class Transaction {
    private int transactionId;
    private double transactionAmount;
    private String transactionType;
    private Date date;
    private double balanceLeft;

    public Transaction(int id, double amount, String type, Date date, double balanceLeft) {
        this.transactionId = id;
        this.transactionType = type;
        this.transactionAmount = amount;
        this.date = date;
        this.balanceLeft = balanceLeft;
    }

    @Override
    public String toString() {
        return "The Transaction id is " + this.transactionId + " Transaction amount is " + this.transactionAmount
                + "Date of Transaction is " + this.date + " The Balance Left is " + this.balanceLeft
                + " The Transation Type is  " + this.transactionType;
    }

}
