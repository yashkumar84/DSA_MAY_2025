import java.util.ArrayList;

public class Account {
    private int accountNumber;
    private double balance;
    private ArrayList<Transaction> transactionHistory;

    public Account(int accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
        this.transactionHistory = new ArrayList<>();
    }
}
