import java.util.ArrayList;
import java.util.Date;

public class Account {
    private int accountNumber;
    private int password;
    private double balance;
    private ArrayList<Transaction> transactionHistory;

    public Account(int accountNumber, int password, double initialBalance) {
        this.accountNumber = accountNumber;
        this.password = password;
        this.balance = initialBalance;
        this.transactionHistory = new ArrayList<>();
    }

    public int getAccountNumber() {
        return this.accountNumber;
    }

    public int getPassword() {
        return this.password;
    }

    public double getbalance() {
        return this.balance;
    }

    public void printTransactionHistory() {
        for (Transaction t : transactionHistory) {
            System.out.println(t);
        }
    }

    public void deposit(double amount) {
        if (amount <= 0) {
            System.out.println("Cannot Deposit Amount Somelthing Went Wrong");
        }
        this.balance += amount;
        this.transactionHistory
                .add(new Transaction(this.accountNumber, amount, "Direct Deposit To Account", new Date(),
                        this.balance));
        System.out.println("Desposit SuccessFull");

    }

    public void withdraw(int amount, int password) {
        if (amount <= 0) {
            System.out.println("Invalid Amount");
            return;
        } else if (amount > balance) {
            System.out.println("insufficient Balance");
            return;
        }
        if (password != this.password) {
            System.out.println("Invalid Password");
        }

        this.balance -= amount;
        int id = (int) Math.random() * 10000;
        this.transactionHistory.add(new Transaction(id, amount, "Withdraw From Account", new Date(), balance));
        System.out.println("WithDraw SuccessFull");
    }

}
