import java.util.ArrayList;

public class Bank {
    String bankName;
    ArrayList<Customer> customers;

    public Bank(String bankName) {
        this.bankName = bankName;
        this.customers = new ArrayList<>();
    }

    public void printCustomers() {
        for (Customer c : customers) {
            System.out.println(c.getCustomerName() + " Account Number is " + c.getAccount().getAccountNumber()
                    + " balance is " + c.getAccount().getbalance());
        }
    }

    public Account getAccountByAccountNumber(int accNo) {
        for (Customer c : customers) {
            if (c.getAccount().getAccountNumber() == accNo) {

                return c.getAccount();
            }
        }

        return null;
    }

    public void addCustomer(Customer customer) {
        for (Customer c : customers) {
            if (c.getAccount().getAccountNumber() == customer.getAccount().getAccountNumber()) {
                System.out.println("Account Already Exists Task Aborted");
                return;
            }
        }
        this.customers.add(customer);
        System.out.println("Customer Added SuccessFully");
    }
}
