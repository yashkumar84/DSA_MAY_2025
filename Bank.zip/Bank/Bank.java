import java.util.ArrayList;

public class Bank {
    String bankName;
    ArrayList<Customer> customers;

    public Bank(String bankName) {
        this.bankName = bankName;
        this.customers = new ArrayList<>();
    }
}
