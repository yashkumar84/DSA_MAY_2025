class Solution {
    int fib(int num) {
        if (num < 2) {
            return num;
        }

        return fib(num - 1) + fib(num - 2);
    }

}

public class Fib {
    public static void main(String[] args) {
        int num = 5;
        Solution sol = new Solution();
        System.out.println(sol.fib(num));
    }

}
