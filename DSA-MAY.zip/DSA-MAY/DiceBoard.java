public class DiceBoard {
    static void diceBoard(int current, int target, String result) {
        if (current == target) {
            System.out.println(result);
            return;
        }

        if (current > target) {
            return;
        }
        for (int i = 1; i <= 6; i++) {
            diceBoard(current + i, target, result + i);
        }
    }

    public static void main(String[] args) {
        diceBoard(0, 10, "");
    }
}
