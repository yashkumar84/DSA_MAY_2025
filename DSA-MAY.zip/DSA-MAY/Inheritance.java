abstract class Vehicle {
    int tyres;
    int mirrors;
    String seatType;
    String color;

    String vehicleName;

    Vehicle(int tyres, int mirrors, String color, String seatType, String vehicleName) {
        this.tyres = tyres;
        this.mirrors = mirrors;
        this.color = color;
        this.seatType = seatType;
        this.vehicleName = vehicleName;
    }

    void engineOn() {
        System.out.println("Engine On");
    }

    void engineOff() {
        System.out.println("Engine Off");
    }

}

abstract class Car extends Vehicle {
    String carName;
    int model;
    boolean isSunRoof;
    String fuelType;
    String steeringType;

    Car(String carName, int model, String fuelType, boolean isSunRoof, String steeringType, int tyres, int mirrors,
            String color, String seatType, String vehicleName) {
        super(tyres, mirrors, color, seatType, vehicleName);
        this.carName = carName;
        this.model = model;
        this.isSunRoof = isSunRoof;
        this.fuelType = fuelType;
        this.steeringType = steeringType;
    }

    void automaticGearShifting() {
        System.out.println("Gear Shifting Starts");
    }
}

class Scorpio extends Car {
    private String mode;
    String variant;

    Scorpio(String mode, String variant, String carName, int model, String fuelType, boolean isSunRoof,
            String steeringType, int tyres, int mirrors,
            String color, String seatType, String vehicleName) {
        super(carName, model, fuelType, isSunRoof, steeringType, tyres, mirrors, color, seatType, vehicleName);
        this.mode = mode;
        this.variant = variant;
    }

    @Override
    void engineOn() {
        System.out.println("Engine On Using Key");

    }

    public String getMode() {
        return this.mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }
}

public class Inheritance {
    public static void main(String[] args) {
        Scorpio scorpio = new Scorpio("4x4", "N", "Scorpio - N", 2025, "Diesel", true, "Elecric", 4, 3, "Black",
                "Leather", "Car");
        System.out.println(scorpio.getMode());
        scorpio.engineOn();
        scorpio.setMode("2 X 2");
        System.out.println(scorpio.getMode());
    }

}
