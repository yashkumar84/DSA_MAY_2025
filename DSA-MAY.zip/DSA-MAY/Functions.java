public class Functions {
    static int printAddition(int a, int b) {
        return a + b;
    }

    static void printName() {
        System.out.println("Yash");
    }

    public static void main(String[] args) {
        int a = 10;
        System.out.println(printAddition(10, 20));
        printName();
    }
}
