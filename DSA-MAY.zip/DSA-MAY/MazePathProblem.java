public class MazePathProblem {
    static void maze(int startingRow, int startingCol, int endingRow, int endingCol, String result) {
        if (startingRow == endingRow && startingCol == endingCol) {
            System.out.println(result);
            return;
        }

        if (startingRow > endingRow || startingCol > endingCol) {
            return;
        }

        maze(startingRow + 1, startingCol, endingRow, endingCol, result + "V");
        maze(startingRow, startingCol + 1, endingRow, endingCol, result + "H");
    }

    public static void main(String[] args) {
        maze(0, 0, 2, 2, "");
    }

}
