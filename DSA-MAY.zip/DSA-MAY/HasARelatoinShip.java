class Car {
    // Wheel w = new Wheel();
    Wheel wheel;

    Car(Wheel wheel) {
        this.wheel = wheel;
    }
}

class Wheel {

}

public class HasARelatoinShip {
    public static void main(String[] args) {
        Wheel wheel = new Wheel();
        Car car = new Car(wheel);
    }

}
