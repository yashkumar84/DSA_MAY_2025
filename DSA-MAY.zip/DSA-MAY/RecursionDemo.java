public class RecursionDemo {
    static void printName(int num) {
        if (num == 0)
            return;

        printName(num - 1);
        

        System.out.println(num);
    }

    public static void main(String[] args) {
        printName(5);
    }
}