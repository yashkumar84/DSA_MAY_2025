public class Loops{
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        int num = 12345;
        int count = 0;
        while(num != 0){
            count++;
            num = num / 10;
        }
       
        System.out.println(count);
       

    }
}