public class PalindromeRec {
    static boolean palindrome(int num, int result, int copy) {
        if (num == 0) {
            if (copy == result) {
                return true;
            } else {
                return false;
            }

        }
        // int rem = num % 10;
        // result = result * 10 + rem;
        // num /= 10;
        return palindrome(num / 10, result * 10 + num % 10, copy);
    }

    public static void main(String[] args) {
        int num = 1222221;
        int result = 0;
        if (palindrome(num, result, num)) {
            System.out.println("The Number is Palindrome");
        } else {
            System.out.println("The Number is Not Palindrome");
        }
    }

}
