import java.util.Scanner;

public class Fibonacci {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int terms = sc.nextInt();
        int a = 0;
        int b = 1;
        System.out.print(a + " ");
        System.out.print(b + " ");
        while (terms > 2) {
            int c = a + b;
            System.out.print(c + " ");
            a = b;
            b = c;
            terms--;
        }
    }

}
