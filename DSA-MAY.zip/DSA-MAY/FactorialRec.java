public class FactorialRec {
    static void fact(int num, int res) {
        if (num == 1) {
            System.out.println("The factorial is " + res);
            return;
        }
        res = res * num;
        fact(num - 1, res);
    }

    static int fact(int num) {
        if (num == 1) {
            return 1;
        }
        return num * fact(num - 1);
    }

    public static void main(String[] args) {
        int num = 5;
        fact(num, 1);
        System.out.println(fact(num));
    }

}
