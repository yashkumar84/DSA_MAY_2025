abstract class Animal {
    abstract void makeSound();

    void eat() {
        System.out.println("The Animal eats Food");
    }

}

class Dog extends Animal {
    @Override
    void makeSound() {
        System.out.println("Bark");
    }
}

public class Abstraction {
    public static void main(String[] args) {
        Animal a = new Dog();
        Dog d = (Dog) a;
        a.eat();
        a.makeSound();
    }

}
