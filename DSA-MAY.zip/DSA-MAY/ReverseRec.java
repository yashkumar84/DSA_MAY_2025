public class ReverseRec {
    static void reverse(int num ,int result){
        if(num == 0){
            System.out.println(result);
            return;
        }
        int rem = num % 10;
        result = result * 10 + rem;
        num /= 10;
        reverse(num, result);
    }
    public static void main(String[] args) {
        int num = 12345;
        reverse(num, 0);

    }
    
}
