public class CountDigitsRec {

    static int count(int num , int ans){
        if(num == 0){
            
            return ans;
        }
       
       return count(num / 10, ans + 1);
    }

    static int count(int num){
        if(num == 0){
            return 0;
        }
        
        return count(num / 10) + 1;
    }
    public static void main(String[] args) {
        int num = 12345;
        count(num, 0);
        System.out.println(count(num));

    }
    
}
