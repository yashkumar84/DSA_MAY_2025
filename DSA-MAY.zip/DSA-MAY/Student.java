interface IStudent {
    // public , protected , private , default

    // public >> protected >> default >> private
    final int max = 10;

    void study();

    void attendClass();

    String getStudentId();
}

class D {
    Student st;

    D(Student st) {
        this.st = st;
    }
}

public class Student implements IStudent {
    String stuId;

    public void study() {
        System.out.println("Student Studies Mnay Subject");
    }

    public void attendClass() {
        System.out.println("Student Attend class Regularly");
    }

    public String getStudentId() {
        return this.stuId;
    }

    public static void main(String[] args) {
        Student stu = new Student();
        stu.stuId = "1234";
        stu.attendClass();
        System.out.println(stu.getStudentId());
    }

}
