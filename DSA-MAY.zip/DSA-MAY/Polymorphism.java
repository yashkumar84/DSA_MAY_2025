class Calc {
    int first;
    int second;
    int third;
    int fourth;

    Calc(int first, int second, int third, int fourth) {
        this.first = first;
        this.second = second;
        this.third = third;
        this.fourth = fourth;
    }

    Calc(int first, int second, int third) {
        this.first = first;
        this.second = second;
        this.third = third;
    }

    Calc(int first, int second) {
        this.first = first;
        this.second = second;
    }

    int add(int first, int second, int third, int fourth) {
        return first + second + third + fourth;
    }

    int add(int first, int second, int third) {
        return first + second + third;
    }

    int add(int first, int second) {
        return first + second + third;
    }

   

}

public class Polymorphism {
    public static void main(String[] args) {
        Calc calc = new Calc(10, 20);
        System.out.println(calc.add(10, 20, 30, 40));
        System.out.println(3);
    }

}
