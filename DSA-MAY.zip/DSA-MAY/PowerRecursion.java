public class PowerRecursion {

    static void power(int num, int exp, int result) {
        if (exp == 0) {
            System.out.println(result);
            return;
        }

        power(num, exp - 1, result * num);
    }

    static int power(int num, int exp) {
        if (exp == 0) {
            return 1;
        }
        int res = power(num, exp - 1);
        return num * res;
    }

    public static void main(String[] args) {
        int num = 3;
        int exp = 3;
        power(num, exp, 1);
        System.out.println(power(num, exp));
    }

}
