class Fan {
    int noOfWings;
    String color;
    double weight;

    Fan(int no, String color, double weight) {
        noOfWings = no;
        this.color = color;
        this.weight = weight;
    }

    Fan(int no, String color) {
        noOfWings = no;
        this.color = color;
    }

    void rotate() {
        System.out.println("The Fan is Rotating");
    }
}

class A {
    A() {

    }
}

public class OOPSDemo {
    public static void main(String[] args) {
        Fan fan = new Fan(3, "Black", 2.5);
        Fan fan1 = new Fan(5, "White", 1.5);
        System.out.println(fan.noOfWings);
        fan.rotate();
        System.out.println(fan1.noOfWings);
        A a = new A();
    }

}
